---
title: "John Doe"
image: "images/author.jpg"
email: "johndoe@logbook.com"
social:
  - icon : "fas fa-facebook" # themify icon pack : https://themify.me/themify-icons
    link : "#"
  - icon : "fas fa-twitter-alt" # themify icon pack : https://themify.me/themify-icons
    link : "#"
  - icon : "fas fa-github" # themify icon pack : https://themify.me/themify-icons
    link : "#"
---

Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin sit amet vulputate augue. Duis auctor lacus id vehicula gravida. Nam suscipit vitae purus et laoreet. Donec nisi dolor, consequat vel pretium id, auctor in dui. Nam iaculis, neque ac ullamcorper. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin sit amet vulputate augue. Duis auctor lacus id vehicula gravida. Nam suscipit vitae purus et laoreet.

Donec nisi dolor, consequat vel pretium id, auctor in dui. Nam iaculis, neque ac ullamcorper.Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin sit amet vulputate augue. 
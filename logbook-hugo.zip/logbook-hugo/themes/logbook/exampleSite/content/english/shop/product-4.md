---
title: "Pink T-Shirt"
date: 2020-03-14T15:40:24+06:00
# post thumb
images:
  - "images/shop/product-4.jpg"
  - "images/shop/product-2.jpg"

# product Price
price: "30.00"
discount_price: "25.00"

# description
description: "This is meta description"
draft: false
---


Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren.
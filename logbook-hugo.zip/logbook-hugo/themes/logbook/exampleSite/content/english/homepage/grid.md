---
title: "Homepage Grid"
post_layout: "grid" # layout value (full, grid or list)
sidebar: "false" # sidebar value (left, right or false)
---
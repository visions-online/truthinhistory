---
title: "Homepage List Left"
post_layout: "list" # layout value (full, grid or list)
sidebar: "left" # sidebar value (left, right or false)
---
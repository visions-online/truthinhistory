---
title: "Homepage Grid Left"
post_layout: "grid" # layout value (full, grid or list)
sidebar: "left" # sidebar value (left, right or false)
---
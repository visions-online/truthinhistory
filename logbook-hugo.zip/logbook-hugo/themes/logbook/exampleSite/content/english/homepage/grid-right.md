---
title: "Homepage Grid Right"
post_layout: "grid" # layout value (full, grid or list)
sidebar: "right" # sidebar value (left, right or false)
---
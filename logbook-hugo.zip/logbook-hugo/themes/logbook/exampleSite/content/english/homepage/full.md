---
title: "Homepage Full"
post_layout: "full" # layout value (full, grid or list)
sidebar: "false" # sidebar value (left, right or false)
---
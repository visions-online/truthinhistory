---
title: "Homepage Full Right"
post_layout: "full" # layout value (full, grid or list)
sidebar: "right" # sidebar value (left, right or false)
---
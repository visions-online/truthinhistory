---
title: "Homepage Full Left"
post_layout: "full" # layout value (full, grid or list)
sidebar: "left" # sidebar value (left, right or false)
---
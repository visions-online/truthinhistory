---
title: "Homepage List"
post_layout: "list" # layout value (full, grid or list)
sidebar: "false" # sidebar value (left, right or false)
---
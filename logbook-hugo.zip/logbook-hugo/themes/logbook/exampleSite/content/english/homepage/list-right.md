---
title: "Homepage List Right"
post_layout: "list" # layout value (full, grid or list)
sidebar: "right" # sidebar value (left, right or false)
---